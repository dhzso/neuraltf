# Dirichlet-Robust Candidate Summary Report — NeuralTF

Inputs: `99` neural candidates ranked by **median integrated score** across 1000 Dirichlet weight draws (k=40, seed=2024), PlanMine annotations, King 2024 supplementary tables, v6→v4 bridge, G0 atlas.

## Method

Same two-track scheme as the fixed-weight pipeline:

- **Track A** — RNAi-validated benchmark TFs. Top 5 by composite.
- **Track B** — novel candidates with a TF domain hit. Top 5.

The key difference: the base score is the **Dirichlet median** (robust to plausible weight perturbations) rather than a single fixed-weight composite.

## Shortlist

| v6 id | gene_name | track | Dirichlet median | composite | human ortholog |
|---|---|---|---|---|---|
| dd_Smed_v6_14115_0_1 | dd14115 | A | 0.8377 | 0.978 | LIM homeobox transcription factor 1-alpha isoform X2 [Homo sapiens] |
| dd_Smed_v6_19890_0_1 | dd19890 | A | 0.7942 | 0.934 | T-box transcription factor TBX20 isoform 1 [Homo sapiens] |
| dd_Smed_v6_26877_0_1 | dd26877 | A | 0.7781 | 0.918 | protein atonal homolog 1 [Homo sapiens] |
| dd_Smed_v6_38342_0_1 | dd38342 | A | 0.7617 | 0.902 | POU domain, class 3, transcription factor 4 [Homo sapiens] |
| dd_Smed_v6_13343_0_1 | dd13343 | A | 0.7841 | 0.874 | LIM/homeobox protein Lhx2 [Homo sapiens] |
| dd_Smed_v6_31217_0_1 | dd31217 | B | 0.6758 | 0.796 | helix-loop-helix protein 1 [Homo sapiens] |
| dd_Smed_v6_12170_0_1 | dd12170 | B | 0.6424 | 0.732 | forkhead box protein J2 [Homo sapiens] |
| dd_Smed_v6_12010_0_1 | dd12010 | B | 0.6294 | 0.719 | putative transcription factor Ovo-like 1 isoform X1 [Homo sapiens] |
| dd_Smed_v6_11930_0_1 | dd11930 | B | 0.6588 | 0.709 |  |
| dd_Smed_v6_16646_0_1 | dd16646 | B | 0.5773 | 0.697 | T-cell acute lymphocytic leukemia protein 1 isoform X3 [Homo sapiens] |

## Comparison with fixed-weight baseline

| gene_name | track | fixed-weight rank | Dirichlet rank | shift |
|---|---|---|---|---|
| dd14115 | A | 1 | 1 | +0 = |
| dd19890 | A | 2 | 2 | +0 = |
| dd26877 | A | 3 | 3 | +0 = |
| dd38342 | A | 4 | 4 | +0 = |
| dd13343 | A | 5 | 5 | +0 = |
| dd31217 | B | 1 | 1 | +0 = |
| dd12170 | B | 2 | 2 | +0 = |
| dd12010 | B | 3 | 3 | +0 = |
| dd11930 | B | 4 | 4 | +0 = |
| dd16646 | B | 5 | 5 | +0 = |

## dd14115 (Track A, rank 1)

- v6 `dd_Smed_v6_14115_0_1` · v4 `dd_Smed_v4_14115_0_1` · `known_rnai_validated`
- Dirichlet median score: `0.8377`
- composite: `0.978` (pipeline integrated `0.838`, 6 evidence streams)
- DNA-binding domains (PlanMine): `Homeobox_CS, Homeobox_dom, Homeodomain-like, Znf_LIM`
- GO terms: DNA binding; axon guidance; camera-type eye development; cell death; cell proliferation; central nervous system neuron development; central nervous system neuron differentiation; cerebellum development; cerebellum morphogenesis; collagen fibril organization; dentate gyrus development; dopaminergic neuron differentiation; embryonic limb morphogenesis; limb morphogenesis; metal ion binding; midbrain
- Human ortholog: LIM homeobox transcription factor 1-alpha isoform X2 [Homo sapiens]
- RNAi note: RNAi-validated (King 2024, mmc5)
- Cross-stage dynamics: G0 progenitor max log2FC `7.82` · X1 neoblast mean (log1p CPM) `0.01`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_14115_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd19890 (Track A, rank 2)

- v6 `dd_Smed_v6_19890_0_1` · v4 `dd_Smed_v4_19890_0_1` · `known_rnai_validated`
- Dirichlet median score: `0.7942`
- composite: `0.934` (pipeline integrated `0.794`, 6 evidence streams)
- DNA-binding domains (PlanMine): `TF_T-box, TF_T-box_CS, p53-like_TF_DNA-bd`
- GO terms: DNA binding; RNA polymerase II activating transcription factor binding; RNA polymerase II regulatory region sequence-specific DNA binding; RNA polymerase II transcription coactivator activity; RNA polymerase II transcription factor binding; aortic valve development; aortic valve morphogenesis; atrial septum morphogenesis; blood circulation; cardiac chamber formation; cardiac muscle tissue morphoge
- Human ortholog: T-box transcription factor TBX20 isoform 1 [Homo sapiens]
- RNAi note: RNAi-validated (King 2024, mmc5)
- Cross-stage dynamics: G0 progenitor max log2FC `5.59` · X1 neoblast mean (log1p CPM) `0.01`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_19890_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd26877 (Track A, rank 3)

- v6 `dd_Smed_v6_26877_0_1` · v4 `dd_Smed_v4_26877_0_1` · `known_rnai_validated`
- Dirichlet median score: `0.7781`
- composite: `0.918` (pipeline integrated `0.778`, 6 evidence streams)
- DNA-binding domains (PlanMine): `bHLH_dom`
- GO terms: DNA binding; apoptotic process; auditory receptor cell differentiation; auditory receptor cell fate determination; auditory receptor cell fate specification; axon guidance; brain development; cell differentiation; central nervous system development; cerebral cortex development; chromatin DNA binding; inner ear development; inner ear morphogenesis; multicellular organismal development; nervous syst
- Human ortholog: protein atonal homolog 1 [Homo sapiens]
- RNAi note: RNAi-validated (King 2024, mmc5)
- Cross-stage dynamics: G0 progenitor max log2FC `5.00` · X1 neoblast mean (log1p CPM) `0.00`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_26877_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd38342 (Track A, rank 4)

- v6 `dd_Smed_v6_38342_0_1` · v4 `dd_Smed_v4_38342_0_1` · `known_rnai_validated`
- Dirichlet median score: `0.7617`
- composite: `0.902` (pipeline integrated `0.762`, 6 evidence streams)
- DNA-binding domains (PlanMine): `Homeobox_CS, Homeobox_dom, Homeodomain-like, Lambda_DNA-bd_dom, POU, POU_specific`
- GO terms: AT DNA binding; DNA binding; cochlea morphogenesis; double-stranded DNA binding; forebrain neuron differentiation; inner ear development; intracellular part; negative regulation of mesenchymal cell apoptotic process; nucleus; regulation of transcription, DNA-templated; sensory perception of sound; sequence-specific DNA binding; transcription factor activity, sequence-specific DNA binding; transcri
- Human ortholog: POU domain, class 3, transcription factor 4 [Homo sapiens]
- RNAi note: RNAi-validated (King 2024, mmc5)
- Cross-stage dynamics: G0 progenitor max log2FC `4.40` · X1 neoblast mean (log1p CPM) `0.00`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_38342_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd13343 (Track A, rank 5)

- v6 `dd_Smed_v6_13343_0_1` · v4 `dd_Smed_v4_13343_0_1` · `known_rnai_validated`
- Dirichlet median score: `0.7841`
- composite: `0.874` (pipeline integrated `0.784`, 6 evidence streams)
- DNA-binding domains (PlanMine): `Homeobox_CS, Homeobox_dom, Homeodomain-like, Znf_LIM`
- Human ortholog: LIM/homeobox protein Lhx2 [Homo sapiens]
- RNAi note: RNAi-validated (King 2024, mmc5)
- Cross-stage dynamics: G0 progenitor max log2FC `6.40` · X1 neoblast mean (log1p CPM) `0.02`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_13343_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd31217 (Track B, rank 1)

- v6 `dd_Smed_v6_31217_0_1` · v4 `dd_Smed_v4_31217_0_1` · `novel_candidate`
- Dirichlet median score: `0.6758`
- composite: `0.796` (pipeline integrated `0.676`, 5 evidence streams)
- DNA-binding domains (PlanMine): `bHLH_dom`
- GO terms: DNA binding; cell differentiation; central nervous system development; multicellular organismal development; nucleus; protein dimerization activity; regulation of transcription, DNA-templated; transcription, DNA-templated
- Human ortholog: helix-loop-helix protein 1 [Homo sapiens]
- RNAi note: Not RNAi-tested in King 2024 mmc5; novel neural-fate candidate
- Cross-stage dynamics: G0 progenitor max log2FC `7.71` · X1 neoblast mean (log1p CPM) `0.00`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_31217_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd12170 (Track B, rank 2)

- v6 `dd_Smed_v6_12170_0_1` · v4 `dd_Smed_v4_12170_0_1` · `novel_candidate`
- Dirichlet median score: `0.6424`
- composite: `0.732` (pipeline integrated `0.642`, 5 evidence streams)
- DNA-binding domains (PlanMine): `TF_fork_head, TF_fork_head_CS, WHTH_DNA-bd_dom`
- GO terms: DNA binding; DNA binding, bending; double-stranded DNA binding; embryo development; nucleolus; nucleus; organ development; pattern specification process; positive regulation of transcription, DNA-templated; protein domain specific binding; regulation of sequence-specific DNA binding transcription factor activity; regulation of transcription, DNA-templated; sequence-specific DNA binding; tissue dev
- Human ortholog: forkhead box protein J2 [Homo sapiens]
- RNAi note: Not RNAi-tested in King 2024 mmc5; novel neural-fate candidate
- Cross-stage dynamics: G0 progenitor max log2FC `4.33` · X1 neoblast mean (log1p CPM) `0.02`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_12170_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd12010 (Track B, rank 3)

- v6 `dd_Smed_v6_12010_0_1` · v4 `dd_Smed_v4_12010_0_1` · `novel_candidate`
- Dirichlet median score: `0.6294`
- composite: `0.719` (pipeline integrated `0.629`, 5 evidence streams)
- DNA-binding domains (PlanMine): `C2H2_Znf_fam, Znf_C2H2, Znf_C2H2-like, Znf_C2H2/integrase_DNA-bd`
- GO terms: DNA binding; epidermis development; intracellular; kidney development; mesoderm development; metal ion binding; negative regulation of transcription from RNA polymerase II promoter; nucleic acid binding; nucleus; pachytene; regulation of transcription, DNA-templated; skin development; spermatogenesis; transcription factor activity, sequence-specific DNA binding; transcription, DNA-templated; trans
- Human ortholog: putative transcription factor Ovo-like 1 isoform X1 [Homo sapiens]
- RNAi note: Not RNAi-tested in King 2024 mmc5; novel neural-fate candidate
- Cross-stage dynamics: G0 progenitor max log2FC `3.05` · X1 neoblast mean (log1p CPM) `0.01`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_12010_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd11930 (Track B, rank 4)

- v6 `dd_Smed_v6_11930_0_1` · v4 `dd_Smed_v4_11930_0_1` · `novel_candidate`
- Dirichlet median score: `0.6588`
- composite: `0.709` (pipeline integrated `0.659`, 5 evidence streams)
- DNA-binding domains (PlanMine): `Znf_C2H2, Znf_C2H2-like`
- RNAi note: Not RNAi-tested in King 2024 mmc5; novel neural-fate candidate
- Cross-stage dynamics: G0 progenitor max log2FC `7.11` · X1 neoblast mean (log1p CPM) `0.09`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_11930_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.

## dd16646 (Track B, rank 5)

- v6 `dd_Smed_v6_16646_0_1` · v4 `dd_Smed_v4_16646_0_1` · `novel_candidate`
- Dirichlet median score: `0.5773`
- composite: `0.697` (pipeline integrated `0.577`, 5 evidence streams)
- DNA-binding domains (PlanMine): `bHLH_dom`
- GO terms: E-box binding; Lsd1/2 complex; RNA polymerase II distal enhancer sequence-specific DNA binding; RNA polymerase II transcription factor activity, sequence-specific DNA binding; RNA polymerase II transcription factor binding; angiogenesis; astrocyte fate commitment; basophil differentiation; cell fate commitment; chromatin binding; definitive hemopoiesis; embryonic hemopoiesis; enzyme binding; eryth
- Human ortholog: T-cell acute lymphocytic leukemia protein 1 isoform X3 [Homo sapiens]
- RNAi note: Not RNAi-tested in King 2024 mmc5; novel neural-fate candidate
- Cross-stage dynamics: G0 progenitor max log2FC `4.17` · X1 neoblast mean (log1p CPM) `0.01`
- Wet-lab suggestion: design dsRNA against nt 300–800 of `dd_Smed_v6_16646_0_1` in `datasets/processed/planmine_transcripts.fasta`; FISH probe ≈ 800 nt antisense over the CDS region.
